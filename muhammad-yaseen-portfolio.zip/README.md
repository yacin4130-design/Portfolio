# Muhammad Yaseen — Digital Marketing & E Commerce Portfolio

Live portfolio: [https://yourusername.github.io/muhammad-yaseen-portfolio](https://yourusername.github.io/muhammad-yaseen-portfolio)

## About

Senior Digital Marketing & E Commerce Manager with 7+ years of experience generating $16M+ in collective revenue with 17,000% average ROAS across global luxury brands.

## Brands Managed

- KITH | COTY | BYD | Jose Eber Beauty | Forever for Love Diamonds | DXB Acoustic | Couture Hair Pro
- MyBreeches.com | Echonik | Deconik | Bag2Pack | Lyon Scent | Frenciiga | Aldar | Emaar | AUM99homes

## Contact

- Dubai UAE: +971 56 556 1226
- Islamabad Pakistan: +92 303 822 4894
- Email: yacin4130@gmail.com
- LinkedIn: linkedin.com/in/muhammad-yaseen
